import { Hexagon, Github, Twitter, Linkedin } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="border-t border-[var(--border)] bg-[#0c0c0d] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
                <Hexagon size={18} className="text-black" fill="black" />
              </div>
              <span className="font-mono-tech font-bold text-lg">
                NEX<span className="text-accent">ARC</span>
              </span>
            </Link>
            <p className="text-sm text-gray-500 max-w-xs">
              Premium multi-brand electronics. Curated tech for people who care about specs.
            </p>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-8 h-8 rounded-lg border border-[var(--border)] flex items-center justify-center text-gray-500 hover:text-accent hover:border-accent transition-colors">
                <Twitter size={16} />
              </a>
              <a href="#" className="w-8 h-8 rounded-lg border border-[var(--border)] flex items-center justify-center text-gray-500 hover:text-accent hover:border-accent transition-colors">
                <Github size={16} />
              </a>
              <a href="#" className="w-8 h-8 rounded-lg border border-[var(--border)] flex items-center justify-center text-gray-500 hover:text-accent hover:border-accent transition-colors">
                <Linkedin size={16} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 mb-3">Shop</h4>
            <ul className="space-y-2">
              <li><Link to="/shop" className="text-sm text-gray-500 hover:text-accent transition-colors">All Products</Link></li>
              <li><Link to="/shop?category=headphones" className="text-sm text-gray-500 hover:text-accent transition-colors">Headphones</Link></li>
              <li><Link to="/shop?category=laptops" className="text-sm text-gray-500 hover:text-accent transition-colors">Laptops</Link></li>
              <li><Link to="/shop?category=smartphones" className="text-sm text-gray-500 hover:text-accent transition-colors">Smartphones</Link></li>
              <li><Link to="/shop?category=cameras" className="text-sm text-gray-500 hover:text-accent transition-colors">Cameras</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 mb-3">Company</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-gray-500 hover:text-accent transition-colors">About Us</a></li>
              <li><a href="#" className="text-sm text-gray-500 hover:text-accent transition-colors">Careers</a></li>
              <li><a href="#" className="text-sm text-gray-500 hover:text-accent transition-colors">Press</a></li>
              <li><a href="#" className="text-sm text-gray-500 hover:text-accent transition-colors">Sustainability</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 mb-3">Support</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-gray-500 hover:text-accent transition-colors">Help Center</a></li>
              <li><a href="#" className="text-sm text-gray-500 hover:text-accent transition-colors">Shipping</a></li>
              <li><a href="#" className="text-sm text-gray-500 hover:text-accent transition-colors">Returns</a></li>
              <li><a href="#" className="text-sm text-gray-500 hover:text-accent transition-colors">Warranty</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-[var(--border)] flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-gray-600 font-mono-tech">
            © 2026 NEXARC. All rights reserved.
          </p>
          <div className="flex gap-6">
            <a href="#" className="text-xs text-gray-600 hover:text-gray-400 transition-colors">Privacy Policy</a>
            <a href="#" className="text-xs text-gray-600 hover:text-gray-400 transition-colors">Terms of Service</a>
            <a href="#" className="text-xs text-gray-600 hover:text-gray-400 transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
