import { Star } from 'lucide-react';

interface StarRatingProps {
  rating: number;
  size?: number;
  showValue?: boolean;
  reviewCount?: number;
}

export default function StarRating({
  rating,
  size = 16,
  showValue = false,
  reviewCount,
}: StarRatingProps) {
  const full = Math.floor(rating);
  const hasHalf = rating - full >= 0.5;
  const empty = 5 - full - (hasHalf ? 1 : 0);

  return (
    <div className="flex items-center gap-1.5">
      <div className="flex items-center">
        {Array.from({ length: full }).map((_, i) => (
          <Star
            key={`full-${i}`}
            size={size}
            className="text-amber-400 fill-amber-400"
          />
        ))}
        {hasHalf && (
          <div className="relative" style={{ width: size, height: size }}>
            <Star size={size} className="text-gray-600 absolute inset-0" />
            <div className="absolute inset-0 overflow-hidden" style={{ width: size / 2 }}>
              <Star size={size} className="text-amber-400 fill-amber-400" />
            </div>
          </div>
        )}
        {Array.from({ length: empty }).map((_, i) => (
          <Star key={`empty-${i}`} size={size} className="text-gray-600" />
        ))}
      </div>
      {showValue && (
        <span className="text-sm text-gray-400 font-mono-tech">
          {rating.toFixed(1)}
          {reviewCount !== undefined && (
            <span className="text-gray-600"> ({reviewCount})</span>
          )}
        </span>
      )}
    </div>
  );
}
