import { Link, useNavigate } from 'react-router-dom';
import { useState, type FormEvent } from 'react';
import { Search, ShoppingCart, Hexagon, GitCompare, X, Menu } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useCompare } from '@/context/CompareContext';

export default function Header() {
  const navigate = useNavigate();
  const { totalItems, openCart } = useCart();
  const { items: compareItems, openCompare } = useCompare();
  const [search, setSearch] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    if (search.trim()) {
      navigate(`/shop?q=${encodeURIComponent(search.trim())}`);
      setSearch('');
      setMobileOpen(false);
    }
  };

  return (
    <>
      <header className="sticky top-0 z-50 glass border-b border-[var(--border)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-4">
            {/* Logo */}
            <Link to="/" className="flex items-center gap-2 shrink-0">
              <div className="w-8 h-8 rounded-lg bg-accent flex items-center justify-center">
                <Hexagon size={18} className="text-black" fill="black" />
              </div>
              <span className="font-mono-tech font-bold text-lg tracking-tight">
                NEX<span className="text-accent">ARC</span>
              </span>
            </Link>

            {/* Search - desktop */}
            <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-xl">
              <div className="relative w-full">
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search products, brands, categories..."
                  className="input-dark pl-10"
                />
              </div>
            </form>

            {/* Nav links - desktop */}
            <nav className="hidden lg:flex items-center gap-1">
              <Link to="/shop" className="btn-ghost text-sm">All Products</Link>
              <Link to="/shop?category=headphones" className="btn-ghost text-sm">Audio</Link>
              <Link to="/shop?category=laptops" className="btn-ghost text-sm">Computing</Link>
              <Link to="/shop?category=smartphones" className="btn-ghost text-sm">Phones</Link>
              <Link to="/compare" className="btn-ghost text-sm">Compare</Link>
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={openCompare}
                className="relative w-9 h-9 rounded-lg glass flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                title="Compare"
              >
                <GitCompare size={18} />
                {compareItems.length > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-accent text-black text-[10px] font-bold flex items-center justify-center">
                    {compareItems.length}
                  </span>
                )}
              </button>
              <button
                onClick={openCart}
                className="relative w-9 h-9 rounded-lg glass flex items-center justify-center text-gray-400 hover:text-white transition-colors"
                title="Cart"
              >
                <ShoppingCart size={18} />
                {totalItems > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-accent text-black text-[10px] font-bold flex items-center justify-center">
                    {totalItems}
                  </span>
                )}
              </button>
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="lg:hidden w-9 h-9 rounded-lg glass flex items-center justify-center text-gray-400"
              >
                {mobileOpen ? <X size={18} /> : <Menu size={18} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-[var(--border)] px-4 py-4 space-y-3 animate-fade-in">
            <form onSubmit={handleSearch}>
              <div className="relative">
                <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search..."
                  className="input-dark pl-10"
                />
              </div>
            </form>
            <div className="flex flex-col gap-1">
              <Link to="/shop" onClick={() => setMobileOpen(false)} className="btn-ghost">All Products</Link>
              <Link to="/shop?category=headphones" onClick={() => setMobileOpen(false)} className="btn-ghost">Audio</Link>
              <Link to="/shop?category=laptops" onClick={() => setMobileOpen(false)} className="btn-ghost">Computing</Link>
              <Link to="/shop?category=smartphones" onClick={() => setMobileOpen(false)} className="btn-ghost">Phones</Link>
              <Link to="/compare" onClick={() => setMobileOpen(false)} className="btn-ghost">Compare</Link>
            </div>
          </div>
        )}
      </header>
    </>
  );
}
