import { Link } from 'react-router-dom';
import { X, ShoppingBag, Trash2, Plus, Minus, ArrowRight } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { formatPrice } from '@/lib/format';

export default function CartDrawer() {
  const { items, isOpen, closeCart, removeFromCart, updateQuantity, subtotal, totalItems } = useCart();

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/60 z-50 animate-fade-in"
        onClick={closeCart}
      />
      <div className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-[var(--bg-elevated)] border-l border-[var(--border)] z-50 flex flex-col animate-slide-in-right">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
          <div className="flex items-center gap-2">
            <ShoppingBag size={20} className="text-accent" />
            <h2 className="font-semibold text-lg">
              Cart {totalItems > 0 && <span className="text-gray-500 text-sm">({totalItems})</span>}
            </h2>
          </div>
          <button onClick={closeCart} className="w-8 h-8 rounded-lg hover:bg-[var(--bg-card)] flex items-center justify-center text-gray-400">
            <X size={18} />
          </button>
        </div>

        {/* Items */}
        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="w-16 h-16 rounded-full border border-[var(--border)] flex items-center justify-center text-gray-600">
              <ShoppingBag size={28} />
            </div>
            <div>
              <p className="text-white font-medium">Your cart is empty</p>
              <p className="text-sm text-gray-500 mt-1">Browse our catalog to find something you'll love.</p>
            </div>
            <button onClick={closeCart} className="btn-primary">
              Start Shopping
            </button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto scrollbar-thin p-5 space-y-4">
              {items.map((item) => (
                <div key={item.product.id} className="flex gap-3">
                  <Link to={`/product/${item.product.slug}`} onClick={closeCart} className="shrink-0">
                    <img
                      src={item.product.image_url}
                      alt={item.product.name}
                      className="w-20 h-20 rounded-lg object-cover bg-[#0e0e10]"
                    />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link to={`/product/${item.product.slug}`} onClick={closeCart}>
                      <h3 className="text-sm font-medium text-white hover:text-accent transition-colors line-clamp-1">
                        {item.product.name}
                      </h3>
                    </Link>
                    <p className="text-xs text-gray-500 font-mono-tech mt-0.5">
                      {formatPrice(item.product.price)}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center border border-[var(--border)] rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                          className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-white"
                        >
                          <Minus size={14} />
                        </button>
                        <span className="w-8 text-center text-sm font-mono-tech">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                          className="w-7 h-7 flex items-center justify-center text-gray-400 hover:text-white"
                        >
                          <Plus size={14} />
                        </button>
                      </div>
                      <button
                        onClick={() => removeFromCart(item.product.id)}
                        className="w-7 h-7 flex items-center justify-center text-gray-600 hover:text-red-400 transition-colors"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                  <div className="text-sm font-bold font-mono-tech text-white shrink-0">
                    {formatPrice(item.product.price * item.quantity)}
                  </div>
                </div>
              ))}
            </div>

            {/* Footer */}
            <div className="border-t border-[var(--border)] p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-400">Subtotal</span>
                <span className="text-xl font-bold font-mono-tech">{formatPrice(subtotal)}</span>
              </div>
              <p className="text-xs text-gray-600">Shipping and taxes calculated at checkout.</p>
              <Link
                to="/checkout"
                onClick={closeCart}
                className="btn-primary w-full"
              >
                Checkout <ArrowRight size={16} />
              </Link>
              <button onClick={closeCart} className="btn-secondary w-full">
                Continue Shopping
              </button>
            </div>
          </>
        )}
      </div>
    </>
  );
}
