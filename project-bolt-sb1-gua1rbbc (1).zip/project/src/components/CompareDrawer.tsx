import { Link } from 'react-router-dom';
import { X, GitCompare, Trash2, ArrowRight } from 'lucide-react';
import { useCompare, MAX_COMPARE } from '@/context/CompareContext';

export default function CompareDrawer() {
  const { items, isOpen, closeCompare, removeFromCompare } = useCompare();

  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/60 z-50 animate-fade-in"
        onClick={closeCompare}
      />
      <div className="fixed right-0 top-0 bottom-0 w-full max-w-md bg-[var(--bg-elevated)] border-l border-[var(--border)] z-50 flex flex-col animate-slide-in-right">
        <div className="flex items-center justify-between p-5 border-b border-[var(--border)]">
          <div className="flex items-center gap-2">
            <GitCompare size={20} className="text-accent" />
            <h2 className="font-semibold text-lg">
              Compare {items.length > 0 && <span className="text-gray-500 text-sm">({items.length}/{MAX_COMPARE})</span>}
            </h2>
          </div>
          <button onClick={closeCompare} className="w-8 h-8 rounded-lg hover:bg-[var(--bg-card)] flex items-center justify-center text-gray-400">
            <X size={18} />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 p-8 text-center">
            <div className="w-16 h-16 rounded-full border border-[var(--border)] flex items-center justify-center text-gray-600">
              <GitCompare size={28} />
            </div>
            <div>
              <p className="text-white font-medium">Nothing to compare yet</p>
              <p className="text-sm text-gray-500 mt-1">Add products to compare their specs side by side.</p>
            </div>
            <Link to="/shop" onClick={closeCompare} className="btn-primary">
              Browse Products
            </Link>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto scrollbar-thin p-5 space-y-3">
              {items.map((product) => (
                <div key={product.id} className="flex gap-3 items-center">
                  <img
                    src={product.image_url}
                    alt={product.name}
                    className="w-16 h-16 rounded-lg object-cover bg-[#0e0e10] shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <Link to={`/product/${product.slug}`} onClick={closeCompare}>
                      <h3 className="text-sm font-medium text-white hover:text-accent transition-colors line-clamp-1">
                        {product.name}
                      </h3>
                    </Link>
                    {product.brand && (
                      <p className="text-xs text-gray-500 mt-0.5">{product.brand.name}</p>
                    )}
                  </div>
                  <button
                    onClick={() => removeFromCompare(product.id)}
                    className="w-7 h-7 flex items-center justify-center text-gray-600 hover:text-red-400 transition-colors"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </div>
            <div className="border-t border-[var(--border)] p-5">
              <Link
                to="/compare"
                onClick={closeCompare}
                className="btn-primary w-full"
              >
                View Comparison <ArrowRight size={16} />
              </Link>
            </div>
          </>
        )}
      </div>
    </>
  );
}
