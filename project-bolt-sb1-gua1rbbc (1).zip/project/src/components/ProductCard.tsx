import { Link } from 'react-router-dom';
import { ShoppingCart, GitCompare, Check } from 'lucide-react';
import type { Product } from '@/types';
import { useCart } from '@/context/CartContext';
import { useCompare } from '@/context/CompareContext';
import { formatPrice } from '@/lib/format';
import StarRating from './StarRating';

export default function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart();
  const { toggleCompare, isInCompare } = useCompare();
  const compared = isInCompare(product.id);

  const discount = product.original_price
    ? Math.round(((product.original_price - product.price) / product.original_price) * 100)
    : 0;

  return (
    <div className="card group flex flex-col overflow-hidden">
      <Link to={`/product/${product.slug}`} className="relative block aspect-square overflow-hidden bg-[#0e0e10]">
        <img
          src={product.image_url}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {discount > 0 && (
            <span className="badge bg-red-500/90 text-white">-{discount}%</span>
          )}
          {!product.in_stock && (
            <span className="badge bg-gray-700 text-gray-300">OUT OF STOCK</span>
          )}
        </div>
        <button
          onClick={(e) => {
            e.preventDefault();
            toggleCompare(product);
          }}
          className={`absolute top-3 right-3 w-8 h-8 rounded-lg flex items-center justify-center transition-all ${
            compared
              ? 'bg-accent text-black'
              : 'glass text-gray-400 hover:text-white'
          }`}
          title={compared ? 'Remove from compare' : 'Add to compare'}
        >
          {compared ? <Check size={16} /> : <GitCompare size={16} />}
        </button>
      </Link>

      <div className="flex flex-col flex-1 p-4">
        {product.brand && (
          <span className="text-xs font-mono-tech uppercase tracking-wider text-gray-500 mb-1">
            {product.brand.name}
          </span>
        )}
        <Link to={`/product/${product.slug}`}>
          <h3 className="font-semibold text-white group-hover:text-accent transition-colors line-clamp-1">
            {product.name}
          </h3>
        </Link>
        <p className="text-sm text-gray-500 mt-1 line-clamp-2 flex-1">
          {product.short_description}
        </p>

        <div className="flex items-center gap-2 mt-3">
          <StarRating rating={product.rating} size={14} showValue reviewCount={product.review_count} />
        </div>

        <div className="flex items-end justify-between mt-4">
          <div className="flex items-baseline gap-2">
            <span className="text-xl font-bold text-white font-mono-tech">
              {formatPrice(product.price)}
            </span>
            {product.original_price && (
              <span className="text-sm text-gray-600 line-through font-mono-tech">
                {formatPrice(product.original_price)}
              </span>
            )}
          </div>
          <button
            onClick={() => addToCart(product)}
            disabled={!product.in_stock}
            className="w-9 h-9 rounded-lg bg-accent text-black flex items-center justify-center hover:shadow-[0_0_20px_rgba(0,212,255,0.3)] transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            title="Add to cart"
          >
            <ShoppingCart size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}
