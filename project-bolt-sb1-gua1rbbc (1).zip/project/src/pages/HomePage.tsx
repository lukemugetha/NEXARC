import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Cpu, Headphones, Laptop, Smartphone, Tablet, Watch, Camera, Gamepad2, Tv, Hexagon, Shield, Truck, RotateCcw } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Product, Category } from '@/types';
import ProductCard from '@/components/ProductCard';

const ICON_MAP: Record<string, typeof Cpu> = {
  Headphones: Headphones,
  Laptop: Laptop,
  Smartphone: Smartphone,
  Tablet: Tablet,
  Watch: Watch,
  Camera: Camera,
  Gamepad2: Gamepad2,
  Tv: Tv,
  Cpu: Cpu,
};

export default function HomePage() {
  const [featured, setFeatured] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const [featRes, catRes] = await Promise.all([
        supabase
          .from('products')
          .select('*, brand:brands(*), category:categories(*)')
          .eq('featured', true)
          .order('rating', { ascending: false })
          .limit(8),
        supabase.from('categories').select('*').order('name'),
      ]);
      setFeatured(featRes.data ?? []);
      setCategories(catRes.data ?? []);
      setLoading(false);
    })();
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden grid-bg">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[var(--bg)]" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-accent opacity-[0.07] blur-[120px] rounded-full" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-6">
              <div className="glow-line w-12" />
              <span className="font-mono-tech text-xs uppercase tracking-[0.2em] text-accent">
                Multi-Brand Electronics
              </span>
            </div>
            <h1 className="text-5xl lg:text-7xl font-bold tracking-tight leading-[1.05]">
              Precision tech for
              <br />
              <span className="text-accent">the next generation.</span>
            </h1>
            <p className="mt-6 text-lg text-gray-400 max-w-xl leading-relaxed">
              From reference-grade audio to workstation-class computing. NEXARC curates the best electronics from five premium brands — with full specs, real reviews, and side-by-side comparison.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Link to="/shop" className="btn-primary text-base px-8 py-3.5">
                Explore Catalog <ArrowRight size={18} />
              </Link>
              <Link to="/compare" className="btn-secondary text-base px-8 py-3.5">
                Compare Products
              </Link>
            </div>

            {/* Stats */}
            <div className="mt-16 grid grid-cols-3 gap-8 max-w-lg">
              <div>
                <div className="text-3xl font-bold font-mono-tech text-white">5</div>
                <div className="text-sm text-gray-500 mt-1">Premium Brands</div>
              </div>
              <div>
                <div className="text-3xl font-bold font-mono-tech text-white">19</div>
                <div className="text-sm text-gray-500 mt-1">Products</div>
              </div>
              <div>
                <div className="text-3xl font-bold font-mono-tech text-white">8</div>
                <div className="text-sm text-gray-500 mt-1">Categories</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust badges */}
      <section className="border-y border-[var(--border)] bg-[#0c0c0d]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="flex items-center gap-3">
              <Truck size={24} className="text-accent" />
              <div>
                <div className="text-sm font-medium">Free Shipping</div>
                <div className="text-xs text-gray-500">On orders over $99</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Shield size={24} className="text-accent" />
              <div>
                <div className="text-sm font-medium">2-Year Warranty</div>
                <div className="text-xs text-gray-500">On all products</div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <RotateCcw size={24} className="text-accent" />
              <div>
                <div className="text-sm font-medium">30-Day Returns</div>
                <div className="text-xs text-gray-500">No questions asked</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold">Shop by Category</h2>
            <p className="text-gray-500 mt-1">Find exactly what you need</p>
          </div>
          <Link to="/shop" className="btn-ghost text-sm hidden sm:flex">
            View All <ArrowRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {categories.map((cat) => {
            const Icon = ICON_MAP[cat.icon] ?? Cpu;
            return (
              <Link
                key={cat.id}
                to={`/shop?category=${cat.slug}`}
                className="card group p-6 flex flex-col items-center text-center hover:border-accent transition-all"
              >
                <div className="w-12 h-12 rounded-xl bg-[var(--bg-elevated)] flex items-center justify-center mb-3 group-hover:bg-accent/10 transition-colors">
                  <Icon size={24} className="text-gray-400 group-hover:text-accent transition-colors" />
                </div>
                <h3 className="font-medium text-white">{cat.name}</h3>
                <p className="text-xs text-gray-500 mt-1 line-clamp-1">{cat.description}</p>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-end justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Hexagon size={16} className="text-accent" />
              <span className="font-mono-tech text-xs uppercase tracking-wider text-accent">Featured</span>
            </div>
            <h2 className="text-2xl font-bold">Top-Rated Tech</h2>
          </div>
          <Link to="/shop" className="btn-ghost text-sm hidden sm:flex">
            View All <ArrowRight size={16} />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="card aspect-[3/4] animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>

      {/* Brand showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="card p-8 lg:p-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-accent opacity-[0.04] blur-[100px] rounded-full" />
          <div className="relative">
            <h2 className="text-2xl font-bold mb-2">Five Brands. One Standard.</h2>
            <p className="text-gray-400 max-w-2xl">
              Each brand in our catalog is selected for engineering excellence. No filler — just products worth your attention.
            </p>
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mt-8">
              {[
                { name: 'Auralux', color: '#fbbf24', desc: 'Audio' },
                { name: 'Nexus', color: '#ff6b35', desc: 'Computing' },
                { name: 'Vortex', color: '#a855f7', desc: 'Gaming' },
                { name: 'Helix', color: '#22c55e', desc: 'Smart Home' },
                { name: 'Optix', color: '#f59e0b', desc: 'Imaging' },
              ].map((brand) => (
                <div key={brand.name} className="text-center p-4 rounded-xl border border-[var(--border)] hover:border-[var(--border-hover)] transition-colors">
                  <div className="w-10 h-10 rounded-lg mx-auto mb-2 flex items-center justify-center" style={{ background: `${brand.color}20`, border: `1px solid ${brand.color}40` }}>
                    <div className="w-3 h-3 rounded-full" style={{ background: brand.color }} />
                  </div>
                  <div className="font-mono-tech font-semibold text-white">{brand.name}</div>
                  <div className="text-xs text-gray-500 mt-0.5">{brand.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
