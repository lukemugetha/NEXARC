import { useEffect, useState, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, X, Search, ChevronDown } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Product, Category, Brand } from '@/types';
import ProductCard from '@/components/ProductCard';

type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest';

export default function ShopPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);

  const [search, setSearch] = useState(searchParams.get('q') ?? '');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') ?? '');
  const [selectedBrand, setSelectedBrand] = useState(searchParams.get('brand') ?? '');
  const [sortBy, setSortBy] = useState<SortOption>('featured');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 3000]);
  const [inStockOnly, setInStockOnly] = useState(false);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    let query = supabase
      .from('products')
      .select('*, brand:brands(*), category:categories(*)');

    if (selectedCategory) {
      query = query.eq('category.slug', selectedCategory);
    }
    if (selectedBrand) {
      query = query.eq('brand.slug', selectedBrand);
    }
    if (inStockOnly) {
      query = query.eq('in_stock', true);
    }
    query = query.gte('price', priceRange[0]).lte('price', priceRange[1]);

    switch (sortBy) {
      case 'price-asc':
        query = query.order('price', { ascending: true });
        break;
      case 'price-desc':
        query = query.order('price', { ascending: false });
        break;
      case 'rating':
        query = query.order('rating', { ascending: false });
        break;
      case 'newest':
        query = query.order('created_at', { ascending: false });
        break;
      default:
        query = query.order('featured', { ascending: false }).order('rating', { ascending: false });
    }

    const { data, error } = await query;
    if (error) {
      console.error('Fetch error:', error);
    }

    let filtered = data ?? [];
    if (search.trim()) {
      const q = search.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.short_description?.toLowerCase().includes(q) ||
          p.brand?.name?.toLowerCase().includes(q) ||
          p.category?.name?.toLowerCase().includes(q)
      );
    }

    setProducts(filtered);
    setLoading(false);
  }, [search, selectedCategory, selectedBrand, sortBy, priceRange, inStockOnly]);

  useEffect(() => {
    (async () => {
      const [catRes, brandRes] = await Promise.all([
        supabase.from('categories').select('*').order('name'),
        supabase.from('brands').select('*').order('name'),
      ]);
      setCategories(catRes.data ?? []);
      setBrands(brandRes.data ?? []);
    })();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [fetchProducts]);

  // Sync URL params
  useEffect(() => {
    const params: Record<string, string> = {};
    if (search) params.q = search;
    if (selectedCategory) params.category = selectedCategory;
    if (selectedBrand) params.brand = selectedBrand;
    setSearchParams(params, { replace: true });
  }, [search, selectedCategory, selectedBrand, setSearchParams]);

  // Read initial params from URL
  useEffect(() => {
    const q = searchParams.get('q');
    const cat = searchParams.get('category');
    const brand = searchParams.get('brand');
    if (q) setSearch(q);
    if (cat) setSelectedCategory(cat);
    if (brand) setSelectedBrand(brand);
  }, [searchParams]);

  const clearFilters = () => {
    setSearch('');
    setSelectedCategory('');
    setSelectedBrand('');
    setSortBy('featured');
    setPriceRange([0, 3000]);
    setInStockOnly(false);
  };

  const hasActiveFilters = search || selectedCategory || selectedBrand || inStockOnly || priceRange[0] > 0 || priceRange[1] < 3000;

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Categories */}
      <div>
        <h3 className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 mb-3">Category</h3>
        <div className="space-y-1">
          <button
            onClick={() => setSelectedCategory('')}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
              !selectedCategory ? 'bg-accent/10 text-accent' : 'text-gray-400 hover:text-white hover:bg-[var(--bg-elevated)]'
            }`}
          >
            All Categories
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.slug)}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                selectedCategory === cat.slug ? 'bg-accent/10 text-accent' : 'text-gray-400 hover:text-white hover:bg-[var(--bg-elevated)]'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Brands */}
      <div>
        <h3 className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 mb-3">Brand</h3>
        <div className="space-y-1">
          <button
            onClick={() => setSelectedBrand('')}
            className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
              !selectedBrand ? 'bg-accent/10 text-accent' : 'text-gray-400 hover:text-white hover:bg-[var(--bg-elevated)]'
            }`}
          >
            All Brands
          </button>
          {brands.map((brand) => (
            <button
              key={brand.id}
              onClick={() => setSelectedBrand(brand.slug)}
              className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors flex items-center gap-2 ${
                selectedBrand === brand.slug ? 'bg-accent/10 text-accent' : 'text-gray-400 hover:text-white hover:bg-[var(--bg-elevated)]'
              }`}
            >
              <div className="w-2 h-2 rounded-full" style={{ background: brand.logo_color }} />
              {brand.name}
            </button>
          ))}
        </div>
      </div>

      {/* Price */}
      <div>
        <h3 className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 mb-3">Price Range</h3>
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <input
              type="number"
              value={priceRange[0]}
              onChange={(e) => setPriceRange([Number(e.target.value), priceRange[1]])}
              className="input-dark text-sm"
              placeholder="Min"
            />
            <span className="text-gray-600">—</span>
            <input
              type="number"
              value={priceRange[1]}
              onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
              className="input-dark text-sm"
              placeholder="Max"
            />
          </div>
          <input
            type="range"
            min={0}
            max={3000}
            step={50}
            value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], Number(e.target.value)])}
            className="w-full accent-cyan-400"
          />
        </div>
      </div>

      {/* In stock */}
      <div>
        <label className="flex items-center gap-2 cursor-pointer">
          <input
            type="checkbox"
            checked={inStockOnly}
            onChange={(e) => setInStockOnly(e.target.checked)}
            className="w-4 h-4 rounded accent-cyan-400"
          />
          <span className="text-sm text-gray-300">In stock only</span>
        </label>
      </div>

      {hasActiveFilters && (
        <button onClick={clearFilters} className="btn-secondary w-full text-sm">
          Clear All Filters
        </button>
      )}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Page header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold">
          {selectedCategory
            ? categories.find((c) => c.slug === selectedCategory)?.name ?? 'Shop'
            : 'All Products'}
        </h1>
        <p className="text-gray-500 mt-1">
          {loading ? 'Loading...' : `${products.length} product${products.length !== 1 ? 's' : ''} found`}
        </p>
      </div>

      {/* Search bar */}
      <div className="relative mb-6">
        <Search size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name, brand, or keyword..."
          className="input-dark pl-10"
        />
        {search && (
          <button
            onClick={() => setSearch('')}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-white"
          >
            <X size={18} />
          </button>
        )}
      </div>

      {/* Sort + filter toggle */}
      <div className="flex items-center justify-between mb-6 gap-4">
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="lg:hidden btn-secondary text-sm"
        >
          <SlidersHorizontal size={16} /> Filters
        </button>

        <div className="hidden lg:block" />

        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500 hidden sm:block">Sort:</span>
          <div className="relative">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as SortOption)}
              className="input-dark text-sm pr-8 appearance-none cursor-pointer"
            >
              <option value="featured">Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Top Rated</option>
              <option value="newest">Newest</option>
            </select>
            <ChevronDown size={16} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none" />
          </div>
        </div>
      </div>

      <div className="flex gap-8">
        {/* Sidebar filters - desktop */}
        <aside className="hidden lg:block w-64 shrink-0">
          <div className="sticky top-24">
            <FilterContent />
          </div>
        </aside>

        {/* Mobile filters */}
        {showFilters && (
          <div className="lg:hidden fixed inset-0 z-50 bg-black/60" onClick={() => setShowFilters(false)}>
            <div className="absolute left-0 top-0 bottom-0 w-80 max-w-full bg-[var(--bg-elevated)] border-r border-[var(--border)] p-6 overflow-y-auto animate-slide-in-right" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-semibold text-lg">Filters</h2>
                <button onClick={() => setShowFilters(false)} className="w-8 h-8 rounded-lg hover:bg-[var(--bg-card)] flex items-center justify-center">
                  <X size={18} />
                </button>
              </div>
              <FilterContent />
            </div>
          </div>
        )}

        {/* Product grid */}
        <div className="flex-1 min-w-0">
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="card aspect-[3/4] animate-pulse" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="card p-12 text-center">
              <p className="text-gray-400 text-lg">No products found</p>
              <p className="text-gray-600 text-sm mt-2">Try adjusting your filters or search terms.</p>
              <button onClick={clearFilters} className="btn-secondary mt-6">
                Clear Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
              {products.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
