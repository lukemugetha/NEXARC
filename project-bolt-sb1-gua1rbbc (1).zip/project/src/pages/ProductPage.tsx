import { useEffect, useState, type FormEvent } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ShoppingCart,
  GitCompare,
  Check,
  ChevronRight,
  Star,
  Truck,
  Shield,
  RotateCcw,
  Minus,
  Plus,
  Cpu,
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Product, Review } from '@/types';
import { useCart } from '@/context/CartContext';
import { useCompare } from '@/context/CompareContext';
import { formatPrice, formatDate } from '@/lib/format';
import StarRating from '@/components/StarRating';
import ProductCard from '@/components/ProductCard';

export default function ProductPage() {
  const { slug } = useParams<{ slug: string }>();
  const { addToCart } = useCart();
  const { toggleCompare, isInCompare } = useCompare();

  const [product, setProduct] = useState<Product | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [related, setRelated] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'specs' | 'reviews'>('specs');

  // Review form
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewTitle, setReviewTitle] = useState('');
  const [reviewBody, setReviewBody] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [reviewError, setReviewError] = useState('');

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    (async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*, brand:brands(*), category:categories(*)')
        .eq('slug', slug)
        .maybeSingle();

      if (error || !data) {
        setProduct(null);
        setLoading(false);
        return;
      }

      setProduct(data);

      // Fetch reviews
      const { data: revData } = await supabase
        .from('reviews')
        .select('*')
        .eq('product_id', data.id)
        .order('created_at', { ascending: false });
      setReviews(revData ?? []);

      // Fetch related products (same category, different product)
      const { data: relData } = await supabase
        .from('products')
        .select('*, brand:brands(*), category:categories(*)')
        .eq('category_id', data.category_id)
        .neq('id', data.id)
        .limit(4);
      setRelated(relData ?? []);

      setLoading(false);
    })();
  }, [slug]);

  const handleAddToCart = () => {
    if (product) addToCart(product, quantity);
  };

  const handleReviewSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!product) return;
    setSubmitting(true);
    setReviewError('');

    if (!reviewName.trim() || !reviewBody.trim()) {
      setReviewError('Please fill in your name and review.');
      setSubmitting(false);
      return;
    }

    const { data, error } = await supabase
      .from('reviews')
      .insert({
        product_id: product.id,
        author_name: reviewName.trim(),
        rating: reviewRating,
        title: reviewTitle.trim() || null,
        body: reviewBody.trim(),
      })
      .select('*')
      .single();

    if (error) {
      setReviewError('Failed to submit review. Please try again.');
      setSubmitting(false);
      return;
    }

    setReviews((prev) => [data, ...prev]);
    setReviewName('');
    setReviewRating(5);
    setReviewTitle('');
    setReviewBody('');
    setSubmitting(false);
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="card aspect-square animate-pulse" />
          <div className="space-y-4">
            <div className="h-8 w-3/4 bg-[var(--bg-card)] rounded animate-pulse" />
            <div className="h-6 w-1/2 bg-[var(--bg-card)] rounded animate-pulse" />
            <div className="h-32 bg-[var(--bg-card)] rounded animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <h1 className="text-2xl font-bold text-white">Product not found</h1>
        <p className="text-gray-500 mt-2">The product you're looking for doesn't exist.</p>
        <Link to="/shop" className="btn-primary mt-6">Back to Shop</Link>
      </div>
    );
  }

  const compared = isInCompare(product.id);
  const discount = product.original_price
    ? Math.round(((product.original_price - product.price) / product.original_price) * 100)
    : 0;

  const specEntries = Object.entries(product.specs ?? {});

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-gray-500 mb-8">
        <Link to="/" className="hover:text-accent">Home</Link>
        <ChevronRight size={14} />
        <Link to="/shop" className="hover:text-accent">Shop</Link>
        {product.category && (
          <>
            <ChevronRight size={14} />
            <Link to={`/shop?category=${product.category.slug}`} className="hover:text-accent">
              {product.category.name}
            </Link>
          </>
        )}
        <ChevronRight size={14} />
        <span className="text-gray-300">{product.name}</span>
      </nav>

      {/* Product main */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Image */}
        <div className="relative">
          <div className="card aspect-square overflow-hidden bg-[#0e0e10]">
            <img
              src={product.image_url}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
          {discount > 0 && (
            <div className="absolute top-4 left-4 badge bg-red-500/90 text-white text-sm px-3 py-1">
              -{discount}% OFF
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          {product.brand && (
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: product.brand.logo_color }} />
              <span className="font-mono-tech text-sm uppercase tracking-wider" style={{ color: product.brand.logo_color }}>
                {product.brand.name}
              </span>
            </div>
          )}

          <h1 className="text-3xl lg:text-4xl font-bold tracking-tight">{product.name}</h1>
          <p className="text-gray-400 mt-3 text-lg">{product.short_description}</p>

          <div className="flex items-center gap-4 mt-4">
            <StarRating rating={product.rating} size={18} showValue reviewCount={product.review_count} />
            <button
              onClick={() => setActiveTab('reviews')}
              className="text-sm text-accent hover:underline"
            >
              Read reviews
            </button>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-3 mt-6">
            <span className="text-4xl font-bold font-mono-tech text-white">
              {formatPrice(product.price)}
            </span>
            {product.original_price && (
              <span className="text-xl text-gray-600 line-through font-mono-tech">
                {formatPrice(product.original_price)}
              </span>
            )}
          </div>

          {/* Stock */}
          <div className="mt-3">
            {product.in_stock ? (
              <span className="badge bg-green-500/15 text-green-400">
                <Check size={12} /> In Stock
              </span>
            ) : (
              <span className="badge bg-gray-700 text-gray-400">Out of Stock</span>
            )}
          </div>

          {/* Description */}
          <p className="text-gray-400 leading-relaxed mt-6">{product.description}</p>

          {/* Features */}
          {product.features && product.features.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-mono-tech uppercase tracking-wider text-gray-400 mb-3">Key Features</h3>
              <ul className="space-y-2">
                {product.features.map((feat, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                    <Check size={16} className="text-accent mt-0.5 shrink-0" />
                    {feat}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center gap-3 mt-8">
            <div className="flex items-center border border-[var(--border)] rounded-lg">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-white"
              >
                <Minus size={16} />
              </button>
              <span className="w-12 text-center font-mono-tech">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="w-10 h-10 flex items-center justify-center text-gray-400 hover:text-white"
              >
                <Plus size={16} />
              </button>
            </div>
            <button
              onClick={handleAddToCart}
              disabled={!product.in_stock}
              className="btn-primary flex-1 py-3 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ShoppingCart size={18} /> Add to Cart
            </button>
            <button
              onClick={() => toggleCompare(product)}
              className={`w-12 h-12 rounded-lg flex items-center justify-center transition-all ${
                compared ? 'bg-accent text-black' : 'btn-secondary'
              }`}
              title={compared ? 'Remove from compare' : 'Add to compare'}
            >
              {compared ? <Check size={18} /> : <GitCompare size={18} />}
            </button>
          </div>

          {/* Trust badges */}
          <div className="grid grid-cols-3 gap-4 mt-8 pt-8 border-t border-[var(--border)]">
            <div className="flex flex-col items-center text-center gap-1">
              <Truck size={20} className="text-accent" />
              <span className="text-xs text-gray-400">Free Shipping</span>
            </div>
            <div className="flex flex-col items-center text-center gap-1">
              <Shield size={20} className="text-accent" />
              <span className="text-xs text-gray-400">2-Year Warranty</span>
            </div>
            <div className="flex flex-col items-center text-center gap-1">
              <RotateCcw size={20} className="text-accent" />
              <span className="text-xs text-gray-400">30-Day Returns</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs: Specs / Reviews */}
      <div className="mt-16">
        <div className="flex gap-1 border-b border-[var(--border)] mb-8">
          <button
            onClick={() => setActiveTab('specs')}
            className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'specs' ? 'border-accent text-accent' : 'border-transparent text-gray-500 hover:text-white'
            }`}
          >
            Tech Specs
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
              activeTab === 'reviews' ? 'border-accent text-accent' : 'border-transparent text-gray-500 hover:text-white'
            }`}
          >
            Reviews ({reviews.length})
          </button>
        </div>

        {/* Specs tab */}
        {activeTab === 'specs' && (
          <div className="animate-fade-in">
            {specEntries.length > 0 ? (
              <div className="card overflow-hidden">
                <table className="w-full">
                  <tbody>
                    {specEntries.map(([key, value], i) => (
                      <tr
                        key={key}
                        className={i % 2 === 0 ? 'bg-[var(--bg-elevated)]/50' : ''}
                      >
                        <td className="px-6 py-4 text-sm font-mono-tech text-gray-400 w-1/3 align-top">
                          {key}
                        </td>
                        <td className="px-6 py-4 text-sm text-white">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-gray-500">No specifications available.</p>
            )}
          </div>
        )}

        {/* Reviews tab */}
        {activeTab === 'reviews' && (
          <div className="animate-fade-in grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Reviews list */}
            <div className="lg:col-span-2 space-y-4">
              {reviews.length === 0 ? (
                <div className="card p-8 text-center">
                  <p className="text-gray-400">No reviews yet. Be the first to share your experience.</p>
                </div>
              ) : (
                reviews.map((review) => (
                  <div key={review.id} className="card p-5">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-[var(--bg-elevated)] flex items-center justify-center font-mono-tech text-sm text-accent">
                            {review.author_name.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-medium text-white">{review.author_name}</p>
                            <p className="text-xs text-gray-600">{formatDate(review.created_at)}</p>
                          </div>
                        </div>
                      </div>
                      <StarRating rating={review.rating} size={14} />
                    </div>
                    {review.title && <h4 className="font-medium text-white mb-1">{review.title}</h4>}
                    <p className="text-sm text-gray-400 leading-relaxed">{review.body}</p>
                  </div>
                ))
              )}
            </div>

            {/* Review form */}
            <div className="lg:col-span-1">
              <div className="card p-6 sticky top-24">
                <h3 className="font-semibold text-lg mb-4">Write a Review</h3>
                <form onSubmit={handleReviewSubmit} className="space-y-4">
                  <div>
                    <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">
                      Your Name
                    </label>
                    <input
                      type="text"
                      value={reviewName}
                      onChange={(e) => setReviewName(e.target.value)}
                      className="input-dark"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">
                      Rating
                    </label>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((r) => (
                        <button
                          key={r}
                          type="button"
                          onClick={() => setReviewRating(r)}
                          className="p-1"
                        >
                          <Star
                            size={24}
                            className={r <= reviewRating ? 'text-amber-400 fill-amber-400' : 'text-gray-600'}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">
                      Title (optional)
                    </label>
                    <input
                      type="text"
                      value={reviewTitle}
                      onChange={(e) => setReviewTitle(e.target.value)}
                      className="input-dark"
                      placeholder="Great product!"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">
                      Review
                    </label>
                    <textarea
                      value={reviewBody}
                      onChange={(e) => setReviewBody(e.target.value)}
                      className="input-dark min-h-[100px] resize-y"
                      placeholder="Share your experience..."
                    />
                  </div>
                  {reviewError && <p className="text-sm text-red-400">{reviewError}</p>}
                  <button
                    type="submit"
                    disabled={submitting}
                    className="btn-primary w-full disabled:opacity-50"
                  >
                    {submitting ? 'Submitting...' : 'Submit Review'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Related products */}
      {related.length > 0 && (
        <div className="mt-20">
          <h2 className="text-2xl font-bold mb-8">Related Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
