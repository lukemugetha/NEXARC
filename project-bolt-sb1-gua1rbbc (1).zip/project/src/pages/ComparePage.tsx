import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { GitCompare, X, Check, ShoppingCart, ArrowRight, Plus } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { Product } from '@/types';
import { useCompare } from '@/context/CompareContext';
import { useCart } from '@/context/CartContext';
import { formatPrice } from '@/lib/format';
import StarRating from '@/components/StarRating';

export default function ComparePage() {
  const { items, removeFromCompare, clearCompare, toggleCompare } = useCompare();
  const { addToCart } = useCart();
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('products')
        .select('*, brand:brands(*), category:categories(*)')
        .order('name');
      setAllProducts(data ?? []);
    })();
  }, []);

  if (items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <div className="w-20 h-20 rounded-full border border-[var(--border)] flex items-center justify-center mx-auto mb-6 text-gray-600">
          <GitCompare size={36} />
        </div>
        <h1 className="text-2xl font-bold text-white">No products to compare</h1>
        <p className="text-gray-500 mt-2 max-w-md mx-auto">
          Add products to your comparison list to see their specifications side by side.
        </p>
        <Link to="/shop" className="btn-primary mt-6">
          Browse Products <ArrowRight size={16} />
        </Link>
      </div>
    );
  }

  // Collect all unique spec keys
  const allSpecKeys: string[] = [];
  items.forEach((p) => {
    Object.keys(p.specs ?? {}).forEach((k) => {
      if (!allSpecKeys.includes(k)) allSpecKeys.push(k);
    });
  });

  const availableToAdd = allProducts.filter(
    (p) => !items.some((c) => c.id === p.id)
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <GitCompare size={18} className="text-accent" />
            <span className="font-mono-tech text-xs uppercase tracking-wider text-accent">Comparison</span>
          </div>
          <h1 className="text-3xl font-bold">Spec Comparison</h1>
          <p className="text-gray-500 mt-1">
            {items.length} product{items.length !== 1 ? 's' : ''} — up to 4 can be compared
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowAdd(!showAdd)} className="btn-secondary text-sm">
            <Plus size={16} /> Add Product
          </button>
          <button onClick={clearCompare} className="btn-ghost text-sm text-gray-500 hover:text-red-400">
            Clear All
          </button>
        </div>
      </div>

      {/* Add product panel */}
      {showAdd && (
        <div className="card p-4 mb-6 animate-fade-in">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 max-h-64 overflow-y-auto scrollbar-thin">
            {availableToAdd.map((p) => (
              <button
                key={p.id}
                onClick={() => {
                  toggleCompare(p);
                  if (items.length >= 3) setShowAdd(false);
                }}
                className="card p-3 flex items-center gap-3 text-left hover:border-accent transition-colors"
              >
                <img src={p.image_url} alt={p.name} className="w-12 h-12 rounded-lg object-cover bg-[#0e0e10] shrink-0" />
                <div className="min-w-0">
                  <p className="text-sm font-medium text-white line-clamp-1">{p.name}</p>
                  <p className="text-xs text-gray-500 font-mono-tech">{formatPrice(p.price)}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Comparison table */}
      <div className="overflow-x-auto scrollbar-thin">
        <div className="min-w-full" style={{ minWidth: `${items.length * 240 + 200}px` }}>
          {/* Product cards row */}
          <div className="grid gap-4 mb-6" style={{ gridTemplateColumns: `200px repeat(${items.length}, 1fr)` }}>
            {/* Empty cell for label column */}
            <div />
            {items.map((product) => (
              <div key={product.id} className="card p-4 relative">
                <button
                  onClick={() => removeFromCompare(product.id)}
                  className="absolute top-2 right-2 w-7 h-7 rounded-lg hover:bg-[var(--bg-elevated)] flex items-center justify-center text-gray-500 hover:text-red-400"
                >
                  <X size={16} />
                </button>
                <Link to={`/product/${product.slug}`}>
                  <img
                    src={product.image_url}
                    alt={product.name}
                    className="w-full aspect-square rounded-lg object-cover bg-[#0e0e10] mb-3"
                  />
                </Link>
                {product.brand && (
                  <span className="text-xs font-mono-tech uppercase tracking-wider" style={{ color: product.brand.logo_color }}>
                    {product.brand.name}
                  </span>
                )}
                <Link to={`/product/${product.slug}`}>
                  <h3 className="font-semibold text-white hover:text-accent transition-colors text-sm mt-1">
                    {product.name}
                  </h3>
                </Link>
                <div className="mt-2">
                  <StarRating rating={product.rating} size={13} showValue reviewCount={product.review_count} />
                </div>
                <div className="flex items-center justify-between mt-3">
                  <span className="text-lg font-bold font-mono-tech text-white">
                    {formatPrice(product.price)}
                  </span>
                  <button
                    onClick={() => addToCart(product)}
                    disabled={!product.in_stock}
                    className="w-8 h-8 rounded-lg bg-accent text-black flex items-center justify-center disabled:opacity-40"
                    title="Add to cart"
                  >
                    <ShoppingCart size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Spec rows */}
          <div className="card overflow-hidden">
            {/* Basic info rows */}
            <CompareRow label="Category" values={items.map((p) => p.category?.name ?? '—')} />
            <CompareRow label="Brand" values={items.map((p) => p.brand?.name ?? '—')} />
            <CompareRow label="Price" values={items.map((p) => formatPrice(p.price))} mono />
            <CompareRow
              label="Original Price"
              values={items.map((p) => (p.original_price ? formatPrice(p.original_price) : '—'))}
              mono
            />
            <CompareRow
              label="Rating"
              values={items.map((p) => `${p.rating.toFixed(1)} / 5`)}
              mono
            />
            <CompareRow
              label="Reviews"
              values={items.map((p) => `${p.review_count}`)}
              mono
            />
            <CompareRow
              label="In Stock"
              values={items.map((p) => (p.in_stock ? 'Yes' : 'No'))}
              isBoolean={items.map((p) => p.in_stock)}
            />

            {/* Divider */}
            <div className="h-px bg-[var(--border)]" />

            {/* Dynamic spec rows */}
            {allSpecKeys.map((key) => (
              <CompareRow
                key={key}
                label={key}
                values={items.map((p) => p.specs?.[key] ?? '—')}
              />
            ))}

            {/* Features */}
            <div className="h-px bg-[var(--border)]" />
            <div className="grid" style={{ gridTemplateColumns: `200px repeat(${items.length}, 1fr)` }}>
              <div className="px-6 py-4 text-xs font-mono-tech uppercase tracking-wider text-gray-400 bg-[var(--bg-elevated)]/50">
                Features
              </div>
              {items.map((product) => (
                <div key={product.id} className="px-4 py-4">
                  <ul className="space-y-1.5">
                    {(product.features ?? []).map((feat, i) => (
                      <li key={i} className="flex items-start gap-1.5 text-xs text-gray-300">
                        <Check size={14} className="text-accent mt-0.5 shrink-0" />
                        {feat}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CompareRow({
  label,
  values,
  mono = false,
  isBoolean,
}: {
  label: string;
  values: string[];
  mono?: boolean;
  isBoolean?: boolean[];
}) {
  return (
    <div className="grid border-b border-[var(--border)] last:border-0" style={{ gridTemplateColumns: `200px repeat(${values.length}, 1fr)` }}>
      <div className="px-6 py-3.5 text-xs font-mono-tech uppercase tracking-wider text-gray-400 bg-[var(--bg-elevated)]/50">
        {label}
      </div>
      {values.map((val, i) => (
        <div key={i} className="px-4 py-3.5 text-sm border-l border-[var(--border)]">
          {isBoolean ? (
            val === 'Yes' ? (
              <Check size={16} className="text-green-400" />
            ) : (
              <X size={16} className="text-red-400" />
            )
          ) : (
            <span className={mono ? 'font-mono-tech text-white' : 'text-gray-200'}>{val}</span>
          )}
        </div>
      ))}
    </div>
  );
}
