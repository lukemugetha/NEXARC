import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Check, CreditCard, Lock, ShoppingBag } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { supabase } from '@/lib/supabase';
import { formatPrice, generateOrderNumber } from '@/lib/format';
import type { Order } from '@/types';

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { items, subtotal, clearCart } = useCart();

  const [step, setStep] = useState<'info' | 'payment' | 'done'>('info');
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState('');
  const [order, setOrder] = useState<Order | null>(null);

  const [form, setForm] = useState({
    name: '',
    email: '',
    address: '',
    city: '',
    zip: '',
    country: 'United States',
    cardNumber: '',
    cardExpiry: '',
    cardCvc: '',
  });

  const shipping = subtotal > 99 ? 0 : 9.99;
  const tax = Math.round(subtotal * 0.08 * 100) / 100;
  const total = subtotal + shipping + tax;

  const update = (key: keyof typeof form, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleInfoSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.address || !form.city || !form.zip) {
      setError('Please fill in all fields.');
      return;
    }
    setError('');
    setStep('payment');
  };

  const handlePaymentSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!form.cardNumber || !form.cardExpiry || !form.cardCvc) {
      setError('Please fill in payment details.');
      return;
    }

    setProcessing(true);
    setError('');

    const orderNumber = generateOrderNumber();
    const orderItems = items.map((item) => ({
      product_id: item.product.id,
      name: item.product.name,
      price: item.product.price,
      quantity: item.quantity,
    }));

    const { data, error: insertError } = await supabase
      .from('orders')
      .insert({
        order_number: orderNumber,
        customer_name: form.name,
        customer_email: form.email,
        shipping_address: form.address,
        city: form.city,
        zip_code: form.zip,
        country: form.country,
        items: orderItems,
        subtotal,
        shipping,
        tax,
        total,
        status: 'confirmed',
      })
      .select('*')
      .single();

    setProcessing(false);

    if (insertError || !data) {
      setError('Failed to place order. Please try again.');
      return;
    }

    setOrder(data as Order);
    clearCart();
    setStep('done');
  };

  // Empty cart guard
  if (items.length === 0 && step !== 'done') {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <div className="w-20 h-20 rounded-full border border-[var(--border)] flex items-center justify-center mx-auto mb-6 text-gray-600">
          <ShoppingBag size={36} />
        </div>
        <h1 className="text-2xl font-bold text-white">Your cart is empty</h1>
        <p className="text-gray-500 mt-2">Add products to your cart before checking out.</p>
        <Link to="/shop" className="btn-primary mt-6">Browse Products</Link>
      </div>
    );
  }

  // Order confirmation
  if (step === 'done' && order) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="card p-8 lg:p-12 text-center animate-slide-up">
          <div className="w-20 h-20 rounded-full bg-green-500/15 flex items-center justify-center mx-auto mb-6">
            <Check size={40} className="text-green-400" />
          </div>
          <h1 className="text-3xl font-bold text-white">Order Confirmed</h1>
          <p className="text-gray-400 mt-2">Thank you, {order.customer_name}! Your order has been placed.</p>

          <div className="mt-8 p-6 rounded-xl bg-[var(--bg-elevated)] border border-[var(--border)] text-left">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-500">Order Number</span>
              <span className="font-mono-tech font-semibold text-accent">{order.order_number}</span>
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-500">Total</span>
              <span className="font-mono-tech font-bold text-lg">{formatPrice(order.total)}</span>
            </div>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-500">Items</span>
              <span className="text-sm">{order.items.length} product{order.items.length !== 1 ? 's' : ''}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">Shipping to</span>
              <span className="text-sm text-right">{order.shipping_address}, {order.city}, {order.zip_code}</span>
            </div>
          </div>

          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <Link to="/shop" className="btn-primary">Continue Shopping</Link>
            <Link to="/" className="btn-secondary">Back to Home</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Back link */}
      <Link to="/shop" className="btn-ghost text-sm mb-6">
        <ArrowLeft size={16} /> Back to Shop
      </Link>

      <h1 className="text-3xl font-bold mb-8">Checkout</h1>

      {/* Progress */}
      <div className="flex items-center gap-4 mb-8">
        <StepIndicator num={1} label="Shipping" active={step === 'info'} done={step === 'payment'} />
        <div className="flex-1 h-px bg-[var(--border)]" />
        <StepIndicator num={2} label="Payment" active={step === 'payment'} done={false} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Form */}
        <div className="lg:col-span-2">
          {step === 'info' && (
            <form onSubmit={handleInfoSubmit} className="card p-6 space-y-5 animate-fade-in">
              <h2 className="text-lg font-semibold mb-2">Shipping Information</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">Full Name</label>
                  <input type="text" value={form.name} onChange={(e) => update('name', e.target.value)} className="input-dark" placeholder="John Doe" />
                </div>
                <div>
                  <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">Email</label>
                  <input type="email" value={form.email} onChange={(e) => update('email', e.target.value)} className="input-dark" placeholder="john@example.com" />
                </div>
              </div>
              <div>
                <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">Address</label>
                <input type="text" value={form.address} onChange={(e) => update('address', e.target.value)} className="input-dark" placeholder="123 Main Street" />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">City</label>
                  <input type="text" value={form.city} onChange={(e) => update('city', e.target.value)} className="input-dark" placeholder="San Francisco" />
                </div>
                <div>
                  <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">ZIP Code</label>
                  <input type="text" value={form.zip} onChange={(e) => update('zip', e.target.value)} className="input-dark" placeholder="94101" />
                </div>
                <div>
                  <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">Country</label>
                  <select value={form.country} onChange={(e) => update('country', e.target.value)} className="input-dark">
                    <option>United States</option>
                    <option>Canada</option>
                    <option>United Kingdom</option>
                    <option>Australia</option>
                    <option>Germany</option>
                  </select>
                </div>
              </div>
              {error && <p className="text-sm text-red-400">{error}</p>}
              <button type="submit" className="btn-primary w-full">
                Continue to Payment
              </button>
            </form>
          )}

          {step === 'payment' && (
            <form onSubmit={handlePaymentSubmit} className="card p-6 space-y-5 animate-fade-in">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-lg font-semibold">Payment Details</h2>
                <div className="flex items-center gap-1.5 text-xs text-gray-500">
                  <Lock size={14} /> Secure checkout
                </div>
              </div>

              <div>
                <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">Card Number</label>
                <div className="relative">
                  <CreditCard size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600" />
                  <input
                    type="text"
                    value={form.cardNumber}
                    onChange={(e) => update('cardNumber', e.target.value)}
                    className="input-dark pl-10 font-mono-tech"
                    placeholder="4242 4242 4242 4242"
                    maxLength={19}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">Expiry (MM/YY)</label>
                  <input type="text" value={form.cardExpiry} onChange={(e) => update('cardExpiry', e.target.value)} className="input-dark font-mono-tech" placeholder="12/28" maxLength={5} />
                </div>
                <div>
                  <label className="text-xs font-mono-tech uppercase tracking-wider text-gray-400 block mb-1.5">CVC</label>
                  <input type="text" value={form.cardCvc} onChange={(e) => update('cardCvc', e.target.value)} className="input-dark font-mono-tech" placeholder="123" maxLength={4} />
                </div>
              </div>

              <div className="p-4 rounded-lg bg-[var(--bg-elevated)] border border-[var(--border)]">
                <p className="text-xs text-gray-500">
                  This is a demo store. No real payment will be processed. Use any card number.
                </p>
              </div>

              {error && <p className="text-sm text-red-400">{error}</p>}

              <div className="flex gap-3">
                <button type="button" onClick={() => setStep('info')} className="btn-secondary flex-1">
                  Back
                </button>
                <button type="submit" disabled={processing} className="btn-primary flex-1 disabled:opacity-50">
                  {processing ? 'Processing...' : `Pay ${formatPrice(total)}`}
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Order summary */}
        <div className="lg:col-span-1">
          <div className="card p-6 sticky top-24">
            <h2 className="font-semibold text-lg mb-4">Order Summary</h2>
            <div className="space-y-3 max-h-64 overflow-y-auto scrollbar-thin mb-4">
              {items.map((item) => (
                <div key={item.product.id} className="flex gap-3">
                  <img src={item.product.image_url} alt={item.product.name} className="w-14 h-14 rounded-lg object-cover bg-[#0e0e10] shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white line-clamp-1">{item.product.name}</p>
                    <p className="text-xs text-gray-500">Qty: {item.quantity}</p>
                  </div>
                  <span className="text-sm font-mono-tech text-white shrink-0">
                    {formatPrice(item.product.price * item.quantity)}
                  </span>
                </div>
              ))}
            </div>

            <div className="space-y-2 pt-4 border-t border-[var(--border)]">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Subtotal</span>
                <span className="font-mono-tech">{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Shipping</span>
                <span className="font-mono-tech">{shipping === 0 ? 'Free' : formatPrice(shipping)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Tax (8%)</span>
                <span className="font-mono-tech">{formatPrice(tax)}</span>
              </div>
              <div className="flex justify-between pt-3 border-t border-[var(--border)]">
                <span className="font-semibold">Total</span>
                <span className="text-xl font-bold font-mono-tech">{formatPrice(total)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function StepIndicator({ num, label, active, done }: { num: number; label: string; active: boolean; done: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-mono-tech transition-colors ${
        done ? 'bg-green-500 text-black' : active ? 'bg-accent text-black' : 'bg-[var(--bg-elevated)] text-gray-500 border border-[var(--border)]'
      }`}>
        {done ? <Check size={16} /> : num}
      </div>
      <span className={`text-sm font-medium ${active || done ? 'text-white' : 'text-gray-500'}`}>{label}</span>
    </div>
  );
}
