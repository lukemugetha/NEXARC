export interface Brand {
  id: string;
  name: string;
  slug: string;
  logo_color: string;
  description: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  description: string;
}

export interface Product {
  id: string;
  brand_id: string;
  category_id: string;
  name: string;
  slug: string;
  price: number;
  original_price: number | null;
  image_url: string;
  short_description: string;
  description: string;
  specs: Record<string, string>;
  features: string[];
  in_stock: boolean;
  rating: number;
  review_count: number;
  featured: boolean;
  created_at: string;
  brand?: Brand;
  category?: Category;
}

export interface Review {
  id: string;
  product_id: string;
  author_name: string;
  rating: number;
  title: string;
  body: string;
  created_at: string;
}

export interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_email: string;
  shipping_address: string;
  city: string;
  zip_code: string;
  country: string;
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  status: string;
  created_at: string;
}

export interface OrderItem {
  product_id: string;
  name: string;
  price: number;
  quantity: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}
