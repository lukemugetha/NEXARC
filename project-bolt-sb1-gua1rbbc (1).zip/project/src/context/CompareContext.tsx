import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Product } from '@/types';

interface CompareContextValue {
  items: Product[];
  isOpen: boolean;
  addToCompare: (product: Product) => void;
  removeFromCompare: (productId: string) => void;
  clearCompare: () => void;
  openCompare: () => void;
  closeCompare: () => void;
  toggleCompare: (product: Product) => void;
  isInCompare: (productId: string) => boolean;
}

const CompareContext = createContext<CompareContextValue | null>(null);

const MAX_COMPARE = 4;

export function CompareProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Product[]>([]);
  const [isOpen, setIsOpen] = useState(false);

  const addToCompare = useCallback((product: Product) => {
    setItems((prev) => {
      if (prev.some((p) => p.id === product.id)) return prev;
      if (prev.length >= MAX_COMPARE) return prev;
      return [...prev, product];
    });
  }, []);

  const removeFromCompare = useCallback((productId: string) => {
    setItems((prev) => prev.filter((p) => p.id !== productId));
  }, []);

  const clearCompare = useCallback(() => setItems([]), []);
  const openCompare = useCallback(() => setIsOpen(true), []);
  const closeCompare = useCallback(() => setIsOpen(false), []);

  const toggleCompare = useCallback((product: Product) => {
    setItems((prev) => {
      if (prev.some((p) => p.id === product.id)) {
        return prev.filter((p) => p.id !== product.id);
      }
      if (prev.length >= MAX_COMPARE) return prev;
      return [...prev, product];
    });
  }, []);

  const isInCompare = useCallback(
    (productId: string) => items.some((p) => p.id === productId),
    [items]
  );

  return (
    <CompareContext.Provider
      value={{
        items,
        isOpen,
        addToCompare,
        removeFromCompare,
        clearCompare,
        openCompare,
        closeCompare,
        toggleCompare,
        isInCompare,
      }}
    >
      {children}
    </CompareContext.Provider>
  );
}

export function useCompare() {
  const ctx = useContext(CompareContext);
  if (!ctx) throw new Error('useCompare must be used within CompareProvider');
  return ctx;
}

export { MAX_COMPARE };
