/*
# Multi-brand consumer electronics ecommerce store

## Overview
Creates the full schema for a dark-technical-aesthetic electronics store with multiple brands, categories, products with tech specs, customer reviews, and an order system. No user authentication — single-tenant public-readable catalog with anon-writable reviews and orders.

## New Tables

1. **brands** — electronics brands (e.g. Auralux, Nexus, Vortex)
   - id (uuid PK)
   - name (text, unique, not null)
   - slug (text, unique, not null)
   - logo_color (text) — hex accent color for brand theming
   - description (text)

2. **categories** — product categories (Headphones, Laptops, Phones, etc.)
   - id (uuid PK)
   - name (text, unique, not null)
   - slug (text, unique, not null)
   - icon (text) — lucide icon name
   - description (text)

3. **products** — individual products
   - id (uuid PK)
   - brand_id (uuid FK → brands)
   - category_id (uuid FK → categories)
   - name (text, not null)
   - slug (text, unique, not null)
   - price (numeric(10,2), not null)
   - original_price (numeric(10,2)) — for showing discounts
   - image_url (text)
   - short_description (text)
   - description (text)
   - specs (jsonb) — flexible tech specs key/value pairs
   - features (text[]) — bullet-point features
   - in_stock (boolean, default true)
   - rating (numeric(3,2), default 0)
   - review_count (integer, default 0)
   - featured (boolean, default false)
   - created_at (timestamptz)

4. **reviews** — customer reviews per product
   - id (uuid PK)
   - product_id (uuid FK → products, ON DELETE CASCADE)
   - author_name (text, not null)
   - rating (integer, 1-5, not null)
   - title (text)
   - body (text)
   - created_at (timestamptz)

5. **orders** — checkout orders
   - id (uuid PK)
   - order_number (text, unique)
   - customer_name (text, not null)
   - customer_email (text, not null)
   - shipping_address (text, not null)
   - city (text, not null)
   - zip_code (text, not null)
   - country (text, default 'United States')
   - items (jsonb) — array of {product_id, name, price, quantity}
   - subtotal (numeric(10,2))
   - shipping (numeric(10,2))
   - tax (numeric(10,2))
   - total (numeric(10,2))
   - status (text, default 'pending')
   - created_at (timestamptz)

## Security
- RLS enabled on all tables.
- Products, brands, categories: public read (anon, authenticated), no writes from frontend.
- Reviews: public read, anon insert (no sign-in required).
- Orders: public read of own order by order_number, anon insert.
- All tables use TO anon, authenticated since there is no sign-in screen.
*/

-- Brands
CREATE TABLE IF NOT EXISTS brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  logo_color text DEFAULT '#00d4ff',
  description text
);

-- Categories
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  icon text DEFAULT 'Cpu',
  description text
);

-- Products
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid REFERENCES brands(id) ON DELETE SET NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  price numeric(10,2) NOT NULL,
  original_price numeric(10,2),
  image_url text,
  short_description text,
  description text,
  specs jsonb DEFAULT '{}'::jsonb,
  features text[] DEFAULT '{}',
  in_stock boolean DEFAULT true,
  rating numeric(3,2) DEFAULT 0,
  review_count integer DEFAULT 0,
  featured boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_brand ON products(brand_id);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(featured);
CREATE INDEX IF NOT EXISTS idx_products_slug ON products(slug);

-- Reviews
CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES products(id) ON DELETE CASCADE,
  author_name text NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  title text,
  body text,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);

-- Orders
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number text UNIQUE NOT NULL,
  customer_name text NOT NULL,
  customer_email text NOT NULL,
  shipping_address text NOT NULL,
  city text NOT NULL,
  zip_code text NOT NULL,
  country text DEFAULT 'United States',
  items jsonb DEFAULT '[]'::jsonb,
  subtotal numeric(10,2) DEFAULT 0,
  shipping numeric(10,2) DEFAULT 0,
  tax numeric(10,2) DEFAULT 0,
  total numeric(10,2) DEFAULT 0,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Brands: public read only
DROP POLICY IF EXISTS "anon_read_brands" ON brands;
CREATE POLICY "anon_read_brands" ON brands FOR SELECT
  TO anon, authenticated USING (true);

-- Categories: public read only
DROP POLICY IF EXISTS "anon_read_categories" ON categories;
CREATE POLICY "anon_read_categories" ON categories FOR SELECT
  TO anon, authenticated USING (true);

-- Products: public read only
DROP POLICY IF EXISTS "anon_read_products" ON products;
CREATE POLICY "anon_read_products" ON products FOR SELECT
  TO anon, authenticated USING (true);

-- Reviews: public read, anon insert
DROP POLICY IF EXISTS "anon_read_reviews" ON reviews;
CREATE POLICY "anon_read_reviews" ON reviews FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_reviews" ON reviews;
CREATE POLICY "anon_insert_reviews" ON reviews FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- Orders: public read, anon insert
DROP POLICY IF EXISTS "anon_read_orders" ON orders;
CREATE POLICY "anon_read_orders" ON orders FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_orders" ON orders;
CREATE POLICY "anon_insert_orders" ON orders FOR INSERT
  TO anon, authenticated WITH CHECK (true);